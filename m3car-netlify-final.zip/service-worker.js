/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "1ac85d1b756ae535e89352344a0f14ff"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4ab5eb5c5dcc93d2442eb646695676b8"
  }, {
    "url": "pwa-192x192.png",
    "revision": "427a8bbc49fe6edcbfbfb8ad256e2005"
  }, {
    "url": "index.html",
    "revision": "f5def51e66123dfbbe764412db36e3f1"
  }, {
    "url": "icon.svg",
    "revision": "0ba364c5c03c8c28305d5943195790ff"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "57bb1c70c0081c9bf62bc79d4d084c19"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/purify.es-Dqk5qvad.js",
    "revision": null
  }, {
    "url": "assets/index.es-wjR8SyWN.js",
    "revision": null
  }, {
    "url": "assets/index-DXRU-QPk.js",
    "revision": null
  }, {
    "url": "assets/index-BLsJ_GSi.css",
    "revision": null
  }, {
    "url": "assets/html2canvas-B4LdPi3d.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "57bb1c70c0081c9bf62bc79d4d084c19"
  }, {
    "url": "icon.svg",
    "revision": "0ba364c5c03c8c28305d5943195790ff"
  }, {
    "url": "pwa-192x192.png",
    "revision": "427a8bbc49fe6edcbfbfb8ad256e2005"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4ab5eb5c5dcc93d2442eb646695676b8"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "1ac85d1b756ae535e89352344a0f14ff"
  }, {
    "url": "manifest.json",
    "revision": "aed49775c6229f0959bcd6c717079043"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//, /^\/\.netlify\//]
  }));

}));
